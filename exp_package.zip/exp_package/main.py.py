from calculator import addition, subtraction, multiplication
num1=int(input("enter a number 1:-"))
num2=int(input("enter a number 2:-"))

print("addition",addition.add(num1,num2))
print("subtraction",subtraction.sub(num1,num2))
print("multiplication",multiplication.multiplication(num1,num2))
